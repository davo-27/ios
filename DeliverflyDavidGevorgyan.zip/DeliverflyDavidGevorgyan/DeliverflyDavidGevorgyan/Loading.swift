//
//  Loading.swift
//  DeleverFlyAlexPetrosyan
//
//  Created by user on 7/2/24.
//

import SwiftUI

struct Loading: View {
    var body: some View {
        
    }
}

#Preview {
    Loading()
}
